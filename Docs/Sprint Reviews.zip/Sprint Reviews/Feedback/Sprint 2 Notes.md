# Sprint 2 Notes

- Put documentation in canvas
- Sprint 3 planning in canvas
- Use Ethernet on PLC
    - "easy" to make it work
- CAN to Arduino is a side project
- Main focus is the communication with the robot

# Next sprint: 

- ST:
    - Talk with the robot via Ethernet (CRI) from the PLC ()
- Unity:
    - ADS implementation in Unity
    - Dynamic speed change in simulation
    - Ability to stop the conveyor belt
    - Position of the object => relative to the objects