## Feedback on Sprint 1

1. Future-proof communication protcol
    - X, Y, Z
    - A, B, C (rotation)
    - Robot movement speed

2. Send CANopen message with a proper ID

3. ADS communication Implementation

4. Basic conveyor belt in Unity