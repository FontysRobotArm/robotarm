# Sprint 3 Planning

- Communication - TwinCAT to Robot arm (Ethernet): (Dimitar, Luuk)

- ADS implementation in Unity (Rik, Jorn)

- Communication - Unity to TwinCAT (Rik, Jorn)

- Dynamic speed change in simulation (Jorn)

- Ability to stop the conveyor belt (Jorn)

- Position of the object => relative to the robot arm (Rik, Jorn)