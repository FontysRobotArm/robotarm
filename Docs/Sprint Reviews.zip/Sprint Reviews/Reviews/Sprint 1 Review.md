# Sprint 1 Review

## What went well
- Consistent meetings
- Communication within the group
- Structured Text syntax and language explorations
- Planning
- Stand-ups
- Version management
- Agile method
- Project documentation
- Discussing problems within group
- Initiative
- Robot movement via factory software

## What did not go so well
- Keeping track of scrum board
- CANopen communication
- TwinCAT 3.1 setup

## Future Improvement
- Keep scrum board in mind
- Ask teachers for assistance
